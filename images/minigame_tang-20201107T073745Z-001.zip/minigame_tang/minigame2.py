import pgzrun
from random import randint

# Game Window Size
WIDTH = 1280
HEIGHT = 720

#bg
bg = Actor('problem_screen1')



def draw():
    screen.blit('problem_screen1',(0,0))
    basket.draw()
    shampoo.draw()
    microwave.draw()
    mobile.draw()
    bag.draw()
    cat.draw()

def place_box():
    box.x = randint(box.width,WIDTH - box.width)
    box.y = 0

def place_shampoo():
    shampoo.x = randint(shampoo.width,WIDTH - shampoo.width)
    shampoo.y = 0

def place_microwave():
    microwave.x = randint(microwave.width,WIDTH - microwave.width)
    microwave.y = 0

def place_mobile():
    mobile.x = randint(mobile.width,WIDTH - mobile.width)
    mobile.y = 0

def place_bag():
    bag.x = randint(bag.width,WIDTH - bag.width)
    bag.y = 0

    
def place_cat():
    cat.x = randint(cat.width,WIDTH - cat.width)
    cat.y = 0

def random_speed():
    cat.y += randint(1,9)
    bag.y += randint(1,9)
    mobile.y += randint(1,9)
    microwave.y += randint(1,9)
    shampoo.y += randint(1,9)
    box.y += randint(1,9)
    
def update():
    random_speed()
    if(keyboard.LEFT):
        basket.x -= 5
    elif(keyboard.RIGHT):
        basket.x += 5

    if(cat.y > HEIGHT):
        place_cat()
    if(bag.y > HEIGHT):
        place_bag()    
    if(shampoo.y > HEIGHT):
        place_shampoo()    
    if(microwave.y > HEIGHT):
        place_microwave()      
    if(mobile.y > HEIGHT):
        place_mobile()
    if(box.y > HEIGHT):
        place_box()




basket = Actor('basket',(628, 507))
box = Actor('box')
shampoo = Actor('shampoo')
microwave = Actor('microwave')
mobile = Actor('mobile')
bag = Actor('bag')
cat = Actor('cat')
pgzrun.go()
